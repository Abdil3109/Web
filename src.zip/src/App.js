import React from 'react';
import Header from "./components/Header";
import 'bootstrap/dist/css/bootstrap.min.css';
import Footer from "./components/Footer"
import './App.css';




function App() {
  return (
   <div>
    <Header/>
    <Footer/>
   </div>

    
  );
}

export default App;



