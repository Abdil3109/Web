export const franc = [
    {
        id: 1,
        title: 'MCU',
        img: 'https://i.pinimg.com/originals/87/b1/a4/87b1a423bc758e8cd96c1139a5495508.jpg'
    },
    {
        id: 2,
        title: 'DCEU',
        img: 'https://sistergeeks.files.wordpress.com/2018/11/dc.jpg'
    },
    {
        id: 3,
        title: 'Lord of the Rings',
        img: 'https://steamuserimages-a.akamaihd.net/ugc/249213870736089767/772F8EEDF08CBAE561FB640181E75A6BE4062703/?imw=512&amp;&amp;ima=fit&amp;impolicy=Letterbox&amp;imcolor=%23000000&amp;letterbox=false'
    },
    {
        id: 4,
        title: '007',
        img: 'https://images.genius.com/5d1c6eba35a6b5b215ce36114132de6a.960x960x1.jpg'
    },
    {
        id: 5,
        title: 'Harry Potter',
        img: 'https://13z1r62pqpkq29c3gw48di6l-wpengine.netdna-ssl.com/wp-content/uploads/2015/09/Wizarding-world-of-harry-potter-logo1.jpg'
    },
    {
        id: 6,
        title: 'Percy Jackson',
        img: 'https://www.logolynx.com/images/logolynx/dc/dcd05e24de744432d912ec35988e549d.jpeg'
    },
    {
        id: 7,
        title: 'Terminator',
        img: 'https://i.ytimg.com/vi/ClYQprimUtE/maxresdefault.jpg'
    },
    {
        id: 8,
        title: 'Indiana Jones',
        img: 'https://1.bp.blogspot.com/_9ordB2k8ZJM/TKD_ZA9qlrI/AAAAAAAAAAw/JgurSZxOER4/s1600/Indiana+Jones.jpg'
    },
    {
        id: 9,
        title: 'Jurassic Park',
        img: 'https://get.wallhere.com/photo/silhouette-movies-logo-dinosaurs-brand-Jurassic-Park-90s-font-240076.jpg'
    },
];