export const data_movie_adventure = [
    {
        id: 1,
        title: 'Pirates of the Caribbean: At Worlds End',
        price: '2007',
        category: 'Adventure',
        linkImg:
            'https://avatars.mds.yandex.net/get-kinopoisk-image/1773646/dfa69f9c-3c71-436f-9b1d-797cd562f04a/300x450',
    },
    {
        id: 2,
        title: 'Pirates of the Caribbean: At Worlds End',
        price: '2007',
        category: 'Adventure',
        linkImg:
            'https://avatars.mds.yandex.net/get-kinopoisk-image/1773646/dfa69f9c-3c71-436f-9b1d-797cd562f04a/300x450',
    },
    {
        id: 3,
        title: 'Pirates of the Caribbean: At Worlds End',
        price: '2007',
        category: 'Adventure',
        linkImg:
            'https://avatars.mds.yandex.net/get-kinopoisk-image/1773646/dfa69f9c-3c71-436f-9b1d-797cd562f04a/300x450',
    },
    {
        id: 4,
        title: 'Pirates of the Caribbean: At Worlds End',
        price: '2007',
        category: 'Adventure',
        linkImg:
            'https://avatars.mds.yandex.net/get-kinopoisk-image/1773646/dfa69f9c-3c71-436f-9b1d-797cd562f04a/300x450',
    },
    {
        id: 5,
        title: 'Pirates of the Caribbean: At Worlds End',
        price: '2007',
        category: 'Adventure',
        linkImg:
            'https://avatars.mds.yandex.net/get-kinopoisk-image/1773646/dfa69f9c-3c71-436f-9b1d-797cd562f04a/300x450',
    },
    {
        id: 6,
        title: 'Pirates of the Caribbean: At Worlds End',
        price: '2007',
        category: 'Adventure',
        linkImg:
            'https://avatars.mds.yandex.net/get-kinopoisk-image/1773646/dfa69f9c-3c71-436f-9b1d-797cd562f04a/300x450',
    },
    {
        id: 7,
        title: 'Pirates of the Caribbean: At Worlds End',
        price: '2007',
        category: 'Adventure',
        linkImg:
            'https://avatars.mds.yandex.net/get-kinopoisk-image/1773646/dfa69f9c-3c71-436f-9b1d-797cd562f04a/300x450',
    },
    {
        id: 8,
        title: 'Pirates of the Caribbean: At Worlds End',
        price: '2007',
        category: 'Adventure',
        linkImg:
            'https://avatars.mds.yandex.net/get-kinopoisk-image/1773646/dfa69f9c-3c71-436f-9b1d-797cd562f04a/300x450',
    },
    {
        id: 9,
        title: 'Pirates of the Caribbean: At Worlds End',
        price: '2007',
        category: 'Adventure',
        linkImg:
            'https://avatars.mds.yandex.net/get-kinopoisk-image/1773646/dfa69f9c-3c71-436f-9b1d-797cd562f04a/300x450',
    },
];