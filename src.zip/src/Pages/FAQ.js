import React, { Component } from 'react'

export default class FAQ extends Component {
  render() {
    return (
      <main>

        
      </main>
    )
  }
}
